package view.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import book.model.BookDao;
import member.model.MemberDao;
import quiz.model.QuizDao;

@Controller
public class GoMainController {
	private final String command = "";
	private final String gotoPage = "Main";
	
	@Autowired
	private MemberDao mdao;
	
	@Autowired
	private BookDao bdao;
	
	@Autowired
	private QuizDao qdao;
	
	@RequestMapping(command)
	public String goMain() {
		
		
		return gotoPage;
	}
	
}
