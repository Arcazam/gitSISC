package quiz.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.databind.ObjectMapper;

import member.model.MemberBean;
import quiz.model.QuizBean;
import quiz.model.QuizDao;

@Controller
public class QuizMakeController {

	@Autowired
	private QuizDao qdao;

	public final String command = "/makeAQ.qz";
	public final String viewPage = "QuizCateList";
	public final String sessionID = "loginInfo";
	public final String gotoPage = "redirect:/cateList.qz";

	@RequestMapping(value = command, method = RequestMethod.GET)
	public String toMakeAQuestion(
				@RequestParam("que_cate") String que_cate,
				HttpSession session, Model model
			) throws JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		
		// ����� ���ǰ� �ҷ��ͼ� BoardList.jsp�� ������ ���� ��ü�� �𵨷� ���� �غ�
		MemberBean mb = (MemberBean) session.getAttribute(sessionID);

		QuizBean qb = new QuizBean();

		qb.setQue_cate(que_cate);

		// �Ѱ��� QuizBeanŸ�� List
		List<QuizBean> list = new ArrayList<QuizBean>();

		// ���� ���� 5���� ���� �迭 ����
		int[] calculate_list = new int[5];

		int start_num = qdao.getStartPoint(qb);
		int end_num = qdao.getEndPoint(qb);
		List<QuizBean> qlist = qdao.getCateQuizList();
		
		calculate_list = range_Question(start_num, end_num);
		
		for (int i = 0; i < 5; i++) {
			QuizBean qb_info = quiz_info(que_cate, calculate_list[i]);
			list.add(qb_info);
		}
		
		model.addAttribute("calculate_list", Arrays.toString(calculate_list));
		model.addAttribute("mb", mb);
		model.addAttribute("que_cate", que_cate);
		model.addAttribute("list", list);
		model.addAttribute("qlist", qlist);

		return viewPage;
	}

	public int[] range_Question(int a, int b) {
		int[] questionList = new int[5];
		Set<Integer> chosenNumbers = new HashSet<Integer>();

		for (int i = 0; i < 5;) {
			int randomQzNum = (int) (Math.random() * (b - a + 1)) + a;

			if (chosenNumbers.add(randomQzNum)) {
				questionList[i] = randomQzNum;
				i++;
			}
		}
		return questionList;
	}

	public QuizBean quiz_info(String que_cate, int qz_num) {
		QuizBean qb = new QuizBean();
		qb.setQz_num(qz_num);
		qb.setQue_cate(que_cate);
		QuizBean sendBean = qdao.makeAQuestion(qb);
		return sendBean;
	}

	@RequestMapping(value = command, method = RequestMethod.POST)
	public String toCorrectQuestion(@ModelAttribute("qb") QuizBean qb, HttpSession session, Model model) {

		// ����� ���ǰ� �ҷ��ͼ� BoardList.jsp�� ������ ���� ��ü�� �𵨷� ���� �غ�
		MemberBean mb = (MemberBean) session.getAttribute(sessionID);

		model.addAttribute("mb", mb);

		return gotoPage;
	}

}